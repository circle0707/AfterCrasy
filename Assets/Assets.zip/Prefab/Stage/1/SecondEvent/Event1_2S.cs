using UnityEngine;

public class Event1_2S : MonoBehaviour
{
    [SerializeField] private GameObject pos1;
    [SerializeField] private GameObject pos2;
    [SerializeField] private GameObject pos3;
    [SerializeField] private GameObject pos4;
    [SerializeField] private GameObject woman;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(woman, pos1.transform.position, pos1.transform.rotation);
            Instantiate(woman, pos1.transform.position, pos1.transform.rotation);
            Instantiate(woman, pos2.transform.position, pos2.transform.rotation);
            Instantiate(woman, pos2.transform.position, pos2.transform.rotation);
            Instantiate(woman, pos3.transform.position, pos3.transform.rotation);
            Instantiate(woman, pos3.transform.position, pos3.transform.rotation);
            Instantiate(woman, pos3.transform.position, pos3.transform.rotation);
            Instantiate(woman, pos4.transform.position, pos4.transform.rotation);
            Instantiate(woman, pos4.transform.position, pos4.transform.rotation);
            Instantiate(woman, pos4.transform.position, pos4.transform.rotation);
            Instantiate(woman, pos4.transform.position, pos4.transform.rotation);
            Destroy(gameObject);
        }
    }
}
